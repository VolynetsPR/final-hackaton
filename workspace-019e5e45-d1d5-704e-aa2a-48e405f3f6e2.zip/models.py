from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Dish(db.Model):
    """Модель блюда в меню"""
    __tablename__ = 'dishes'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    composition = db.Column(db.Text)
    quantity = db.Column(db.String(50))  # в граммах/штуках
    price = db.Column(db.Integer, nullable=False)  # в рублях
    dish_type = db.Column(db.String(50), nullable=False)  # тип блюда
    short_name = db.Column(db.String(100))  # краткое название
    is_supplier = db.Column(db.Boolean, default=True)  # True - меню поставщика, False - собственное
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'composition': self.composition,
            'quantity': self.quantity,
            'price': self.price,
            'dish_type': self.dish_type,
            'short_name': self.short_name,
            'is_supplier': self.is_supplier
        }


class ModuleMenu(db.Model):
    """Меню на модуль - привязка дня недели к блюдам"""
    __tablename__ = 'module_menu'

    id = db.Column(db.Integer, primary_key=True)
    day_of_week = db.Column(db.Integer, nullable=False)  # 1=Пн, 2=Вт, ... 6=Сб
    slot_number = db.Column(db.Integer, nullable=False)  # номер слота (1 или 2) для каждого типа
    dish_type = db.Column(db.String(50), nullable=False)  # тип блюда
    dish_id = db.Column(db.Integer, db.ForeignKey('dishes.id'))

    dish = db.relationship('Dish', backref='module_menus')


class User(db.Model):
    """Пользователь (лицеист)"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    name = db.Column(db.String(100))  # имя
    surname = db.Column(db.String(100))  # фамилия
    patronymic = db.Column(db.String(100))  # отчество
    student_class = db.Column(db.String(20))  # класс, например "6А"
    class_teacher = db.Column(db.String(200))  # классный руководитель
    password_hash = db.Column(db.String(255))
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'surname': self.surname,
            'patronymic': self.patronymic,
            'student_class': self.student_class,
            'class_teacher': self.class_teacher
        }


class VerificationCode(db.Model):
    """Коды верификации для входа"""
    __tablename__ = 'verification_codes'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), nullable=False)
    code = db.Column(db.String(6), nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    used = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Order(db.Model):
    """Заказ питания"""
    __tablename__ = 'orders'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    week_start_date = db.Column(db.Date, nullable=False)  # дата начала недели (понедельник)
    total_amount = db.Column(db.Integer, default=0)
    payment_proof = db.Column(db.String(500))  # путь к файлу подтверждения оплаты
    status = db.Column(db.String(20), default='pending')  # pending, paid, confirmed, problem
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref='orders')
    items = db.relationship('OrderItem', backref='order', cascade='all, delete-orphan')


class OrderItem(db.Model):
    """Элемент заказа - конкретное блюдо в заказе"""
    __tablename__ = 'order_items'

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    dish_id = db.Column(db.Integer, db.ForeignKey('dishes.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # день недели
    quantity = db.Column(db.Integer, default=0)

    dish = db.relationship('Dish', backref='order_items')


# Справочник классных руководителей (упрощённо)
CLASS_TEACHERS = {
    '5А': 'Иванова А.С.',
    '5Б': 'Петрова Б.В.',
    '5В': 'Сидорова В.Г.',
    '6А': 'Козлова Г.Д.',
    '6Б': 'Новикова Д.Е.',
    '6В': 'Морозова Е.Ж.',
    '7А': 'Волкова Ж.З.',
    '7Б': 'Зайцева З.И.',
    '7В': 'Соловьева И.К.',
    '8А': 'Кузнецова К.Л.',
    '8Б': 'Лебедева Л.М.',
    '8В': 'Попова М.Н.',
    '9А': 'Орлова Н.О.',
    '9Б': 'Николаева О.П.',
    '9В': 'Андреева П.Р.',
    '10А': 'Сергеева Р.С.',
    '10Б': 'Семенова С.Т.',
    '10В': 'Миронова Т.У.',
    '11А': 'Федорова У.Ф.',
    '11Б': 'Чернова Ф.Х.',
    '11В': 'Шестакова Х.Ц.',
}


def get_class_teacher(class_name):
    """Получить классного руководителя по классу"""
    return CLASS_TEACHERS.get(class_name, 'Не назначен')