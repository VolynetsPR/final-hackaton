from flask import Flask, render_template, request, redirect, url_for, session, send_file, flash, current_app
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, Dish, ModuleMenu, User, VerificationCode, Order, OrderItem, get_class_teacher
from datetime import datetime, timedelta, date
from functools import wraps
import os
import random
import string
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'food-order-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///food_order.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'pdf'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

db.init_app(app)

# Создаём папку для загрузок
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


# ======================= ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ =======================

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def generate_verification_code():
    """Генерация 6-значного кода"""
    return ''.join(random.choices(string.digits, k=6))


def get_current_week_start():
    """Получить дату начала текущей недели (понедельник)"""
    today = date.today()
    return today - timedelta(days=today.weekday())


def get_next_week_start():
    """Получить дату начала следующей недели (понедельник)"""
    today = date.today()
    next_monday = today + timedelta(days=(7 - today.weekday()))
    return next_monday


def week_range(week_start):
    """Получить диапазон дат недели"""
    return [week_start + timedelta(days=i) for i in range(6)]  # Пн-Сб


DAY_NAMES = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота']
DISH_TYPES = ['Суп', 'Салат', 'Второе горячее блюдо', 'Гарнир', 'Напиток', 'Готовое кулинарное блюдо', 'Хлеб']
DISH_TYPES_KEYS = ['soup', 'salad', 'main', 'side', 'drink', 'ready', 'bread']


# ======================= ДЕКОРАТОРЫ =======================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            flash('Доступ запрещён', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


# ======================= ГЛАВНАЯ СТРАНИЦА =======================

@app.route('/')
def index():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            return render_template('index.html', user=user)
    return redirect(url_for('login'))


# ======================= АВТОРИЗАЦИЯ =======================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        
        if not email:
            flash('Введите email', 'error')
            return render_template('login.html')
        
        # Проверяем существование пользователя
        user = User.query.filter_by(email=email).first()
        
        # Генерируем код верификации
        code = generate_verification_code()
        expires_at = datetime.utcnow() + timedelta(minutes=10)
        
        verification = VerificationCode(
            email=email,
            code=code,
            expires_at=expires_at
        )
        db.session.add(verification)
        
        # Если пользователя нет - создаём (для новых пользователей)
        if not user:
            user = User(email=email)
            db.session.add(user)
        
        db.session.commit()
        
        # В реальности код отправляется на email
        # Для демо показываем код на странице
        session['pending_email'] = email
        session['verification_code'] = code  # Для демо! В продакшене не делать!
        
        flash(f'Код отправлен на {email}. Демо-режим: ваш код - {code}', 'info')
        return redirect(url_for('verify_code'))
    
    return render_template('login.html')


@app.route('/verify', methods=['GET', 'POST'])
def verify_code():
    if 'pending_email' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        code = request.form.get('code', '').strip()
        email = session['pending_email']
        
        # Находим валидный код
        verification = VerificationCode.query.filter_by(
            email=email,
            code=code,
            used=False
        ).filter(VerificationCode.expires_at > datetime.utcnow()).first()
        
        if verification:
            verification.used = True
            
            user = User.query.filter_by(email=email).first()
            if user:
                session['user_id'] = user.id
            
            session.pop('pending_email', None)
            session.pop('verification_code', None)
            
            flash('Вход выполнен успешно!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверный код или срок действия истёк', 'error')
    
    return render_template('verify.html', email=session.get('pending_email'))


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('pending_email', None)
    session.pop('verification_code', None)
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))


# ======================= ЛИЧНЫЙ КАБИНЕТ =======================

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        user.name = request.form.get('name', '').strip()
        user.surname = request.form.get('surname', '').strip()
        user.patronymic = request.form.get('patronymic', '').strip()
        user.student_class = request.form.get('student_class', '').strip()
        
        if user.student_class:
            user.class_teacher = get_class_teacher(user.student_class)
        
        db.session.commit()
        flash('Профиль обновлён', 'success')
    
    return render_template('profile.html', user=user, CLASS_TEACHERS=User.query.filter_by().all())


# ======================= УПРАВЛЕНИЕ МЕНЮ =======================

@app.route('/menu')
@admin_required
def menu_list():
    dishes = Dish.query.order_by(Dish.dish_type, Dish.name).all()
    
    # Группируем по типам
    grouped = {}
    for dish in dishes:
        if dish.dish_type not in grouped:
            grouped[dish.dish_type] = []
        grouped[dish.dish_type].append(dish)
    
    return render_template('menu/list.html', grouped=grouped, DISH_TYPES=DISH_TYPES)


@app.route('/menu/add', methods=['GET', 'POST'])
@admin_required
def menu_add():
    if request.method == 'POST':
        dish = Dish(
            name=request.form.get('name', '').strip(),
            composition=request.form.get('composition', '').strip(),
            quantity=request.form.get('quantity', '').strip(),
            price=int(request.form.get('price', 0)),
            dish_type=request.form.get('dish_type', ''),
            short_name=request.form.get('short_name', '').strip(),
            is_supplier=request.form.get('is_supplier', '1') == '1'
        )
        db.session.add(dish)
        db.session.commit()
        flash('Блюдо добавлено', 'success')
        return redirect(url_for('menu_list'))
    
    return render_template('menu/add.html', DISH_TYPES=DISH_TYPES)


@app.route('/menu/edit/<int:dish_id>', methods=['GET', 'POST'])
@admin_required
def menu_edit(dish_id):
    dish = Dish.query.get_or_404(dish_id)
    
    if request.method == 'POST':
        dish.name = request.form.get('name', '').strip()
        dish.composition = request.form.get('composition', '').strip()
        dish.quantity = request.form.get('quantity', '').strip()
        dish.price = int(request.form.get('price', 0))
        dish.dish_type = request.form.get('dish_type', '')
        dish.short_name = request.form.get('short_name', '').strip()
        dish.is_supplier = request.form.get('is_supplier', '1') == '1'
        
        db.session.commit()
        flash('Блюдо обновлено', 'success')
        return redirect(url_for('menu_list'))
    
    return render_template('menu/edit.html', dish=dish, DISH_TYPES=DISH_TYPES)


@app.route('/menu/delete/<int:dish_id>', methods=['POST'])
@admin_required
def menu_delete(dish_id):
    dish = Dish.query.get_or_404(dish_id)
    db.session.delete(dish)
    db.session.commit()
    flash('Блюдо удалено', 'success')
    return redirect(url_for('menu_list'))


@app.route('/menu/upload', methods=['GET', 'POST'])
@admin_required
def menu_upload():
    """Загрузка меню из файла"""
    if request.method == 'POST':
        menu_type = request.form.get('menu_type', 'supplier')  # supplier или own
        is_supplier = menu_type == 'supplier'
        
        file = request.files.get('menu_file')
        if not file or file.filename == '':
            flash('Выберите файл', 'error')
            return redirect(request.url)
        
        # Парсим файл
        content = file.read().decode('utf-8')
        lines = content.strip().split('\n')
        
        # Удаляем старые записи этого типа меню
        Dish.query.filter_by(is_supplier=is_supplier).delete()
        
        # Парсим CSV
        for line in lines:
            if not line.strip():
                continue
            
            parts = [p.strip() for p in line.split('\t')]
            if len(parts) >= 5:
                name = parts[0]
                composition = parts[1] if len(parts) > 1 else ''
                quantity = parts[2] if len(parts) > 2 else ''
                price_str = parts[3] if len(parts) > 3 else '0'
                dish_type = parts[4] if len(parts) > 4 else ''
                
                # Извлекаем цену (убираем ₽)
                price = int(''.join(filter(str.isdigit, price_str)))
                
                # Определяем тип блюда
                dish_type_normalized = normalize_dish_type(dish_type)
                
                dish = Dish(
                    name=name,
                    composition=composition,
                    quantity=quantity,
                    price=price,
                    dish_type=dish_type_normalized,
                    is_supplier=is_supplier
                )
                db.session.add(dish)
        
        db.session.commit()
        flash(f'Меню загружено ({menu_type})', 'success')
        return redirect(url_for('menu_list'))
    
    return render_template('menu/upload.html')


def normalize_dish_type(dish_type):
    """Нормализация типа блюда"""
    dish_type = dish_type.lower()
    if 'втор' in dish_type or 'горяч' in dish_type:
        return 'Второе горячее блюдо'
    elif 'гарнир' in dish_type:
        return 'Гарнир'
    elif 'готов' in dish_type or 'кулинар' in dish_type:
        return 'Готовое кулинарное блюдо'
    elif 'напиток' in dish_type:
        return 'Напиток'
    elif 'салат' in dish_type:
        return 'Салат'
    elif 'суп' in dish_type:
        return 'Суп'
    elif 'хлеб' in dish_type:
        return 'Хлеб'
    return dish_type


# ======================= МЕНЮ НА МОДУЛЬ =======================

@app.route('/module-menu', methods=['GET', 'POST'])
@admin_required
def module_menu_edit():
    """Редактирование меню на модуль"""
    if request.method == 'POST':
        # Очищаем старое меню
        ModuleMenu.query.delete()
        
        # Сохраняем выбранные блюда для каждого дня
        for day in range(1, 7):  # Пн-Сб
            for slot in range(1, 3):  # До 2 блюд каждого типа
                for dish_type_key in DISH_TYPES_KEYS:
                    field_name = f'day{day}_{dish_type_key}_{slot}'
                    dish_id = request.form.get(field_name)
                    
                    if dish_id and dish_id != '0':
                        menu_item = ModuleMenu(
                            day_of_week=day,
                            slot_number=slot,
                            dish_type=DISH_TYPES[DISH_TYPES_KEYS.index(dish_type_key)],
                            dish_id=int(dish_id)
                        )
                        db.session.add(menu_item)
        
        db.session.commit()
        flash('Меню на модуль сохранено', 'success')
        return redirect(url_for('module_menu_edit'))
    
    # Получаем текущее меню
    current_menu = {}
    for item in ModuleMenu.query.all():
        key = f"day{item.day_of_week}_{item.dish_type}_{item.slot_number}"
        current_menu[key] = item.dish_id
    
    # Получаем все блюда по типам
    dishes_by_type = {}
    for dish_type in DISH_TYPES:
        dishes_by_type[dish_type] = Dish.query.filter_by(dish_type=dish_type).all()
    
    return render_template('menu/module_menu.html', 
                         current_menu=current_menu,
                         dishes_by_type=dishes_by_type,
                         DAY_NAMES=DAY_NAMES,
                         DISH_TYPES=DISH_TYPES,
                         DISH_TYPES_KEYS=DISH_TYPES_KEYS)


@app.route('/module-menu/export')
@admin_required
def module_menu_export():
    """Экспорт меню на модуль в JSON файл"""
    menu_items = ModuleMenu.query.all()
    
    export_data = []
    for item in menu_items:
        export_data.append({
            'day': item.day_of_week,
            'day_name': DAY_NAMES[item.day_of_week - 1],
            'type': item.dish_type,
            'slot': item.slot_number,
            'dish_name': item.dish.name if item.dish else '',
            'price': item.dish.price if item.dish else 0
        })
    
    # Сортируем по дням
    export_data.sort(key=lambda x: (x['day'], x['slot']))
    
    response = app.response_class(
        response=json.dumps(export_data, ensure_ascii=False, indent=2),
        status=200,
        mimetype='application/json'
    )
    response.headers['Content-Disposition'] = 'attachment; filename=module_menu.json'
    return response


# ======================= ЗАКАЗЫ =======================

@app.route('/order', methods=['GET', 'POST'])
@login_required
def order_create():
    """Формирование заказа на неделю"""
    user = User.query.get(session['user_id'])
    
    if not user.surname or not user.student_class:
        flash('Заполните профиль перед заказом', 'warning')
        return redirect(url_for('profile'))
    
    week_start = get_next_week_start()
    week_dates = week_range(week_start)
    
    # Получаем меню на модуль
    module_menu = get_module_menu_by_day()
    
    if request.method == 'POST':
        # Создаём заказ
        order = Order(
            user_id=user.id,
            week_start_date=week_start,
            status='draft'
        )
        db.session.add(order)
        db.session.flush()
        
        total = 0
        
        for day in range(1, 7):
            for dish_type in DISH_TYPES:
                for slot in range(1, 3):
                    field_name = f'day{day}_{dish_type}_{slot}'
                    quantity = int(request.form.get(field_name, 0) or 0)
                    
                    if quantity > 0:
                        # Находим блюдо
                        menu_item = ModuleMenu.query.filter_by(
                            day_of_week=day,
                            dish_type=dish_type,
                            slot_number=slot
                        ).first()
                        
                        if menu_item and menu_item.dish:
                            item = OrderItem(
                                order_id=order.id,
                                dish_id=menu_item.dish_id,
                                day_of_week=day,
                                quantity=quantity
                            )
                            db.session.add(item)
                            total += menu_item.dish.price * quantity
        
        order.total_amount = total
        order.status = 'pending'
        db.session.commit()
        
        flash('Заказ сохранён. Нажмите "Оплатить" для подтверждения.', 'success')
        return redirect(url_for('order_confirm', order_id=order.id))
    
    return render_template('order/create.html', 
                         user=user,
                         week_start=week_start,
                         week_dates=week_dates,
                         module_menu=module_menu,
                         DAY_NAMES=DAY_NAMES,
                         DISH_TYPES=DISH_TYPES)


def get_module_menu_by_day():
    """Получить меню на модуль сгруппированное по дням"""
    menu = {}
    for day in range(1, 7):
        menu[day] = {}
        for dish_type in DISH_TYPES:
            menu[day][dish_type] = []
            for slot in range(1, 3):
                item = ModuleMenu.query.filter_by(
                    day_of_week=day,
                    dish_type=dish_type,
                    slot_number=slot
                ).first()
                if item and item.dish:
                    menu[day][dish_type].append(item.dish)
    return menu


@app.route('/order/confirm/<int:order_id>')
@login_required
def order_confirm(order_id):
    """Подтверждение заказа"""
    order = Order.query.get_or_404(order_id)
    
    if order.user_id != session['user_id']:
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    
    # Группируем items по дням
    items_by_day = {}
    day_totals = {}
    
    for item in order.items:
        if item.day_of_week not in items_by_day:
            items_by_day[item.day_of_week] = []
            day_totals[item.day_of_week] = 0
        items_by_day[item.day_of_week].append(item)
        day_totals[item.day_of_week] += item.dish.price * item.quantity
    
    week_dates = week_range(order.week_start_date)
    
    return render_template('order/confirm.html',
                         order=order,
                         items_by_day=items_by_day,
                         day_totals=day_totals,
                         week_dates=week_dates,
                         DAY_NAMES=DAY_NAMES,
                         DISH_TYPES=DISH_TYPES)


@app.route('/order/pay/<int:order_id>', methods=['GET', 'POST'])
@login_required
def order_pay(order_id):
    """Оплата заказа"""
    order = Order.query.get_or_404(order_id)
    
    if order.user_id != session['user_id']:
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        file = request.files.get('payment_proof')
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(f"order_{order.id}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            order.payment_proof = filepath
            order.status = 'paid'
            db.session.commit()
            flash('Оплата отправлена на проверку', 'success')
            return redirect(url_for('order_success', order_id=order.id))
        else:
            flash('Прикрепите подтверждение оплаты (PDF, PNG, JPG)', 'error')
    
    return render_template('order/pay.html', order=order)


@app.route('/order/success/<int:order_id>')
@login_required
def order_success(order_id):
    """Успешный заказ"""
    order = Order.query.get_or_404(order_id)
    
    if order.user_id != session['user_id']:
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    
    return render_template('order/success.html', order=order)


@app.route('/orders/history')
@login_required
def orders_history():
    """История заказов"""
    user = User.query.get(session['user_id'])
    orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).all()
    return render_template('order/history.html', orders=orders)


@app.route('/order/view/<int:order_id>')
@login_required
def order_view(order_id):
    """Просмотр заказа (из истории)"""
    order = Order.query.get_or_404(order_id)
    
    # Проверяем доступ
    user = User.query.get(session['user_id'])
    if order.user_id != user.id and not user.is_admin:
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    
    items_by_day = {}
    day_totals = {}
    
    for item in order.items:
        if item.day_of_week not in items_by_day:
            items_by_day[item.day_of_week] = []
            day_totals[item.day_of_week] = 0
        items_by_day[item.day_of_week].append(item)
        day_totals[item.day_of_week] += item.dish.price * item.quantity
    
    week_dates = week_range(order.week_start_date)
    
    return render_template('order/view.html',
                         order=order,
                         items_by_day=items_by_day,
                         day_totals=day_totals,
                         week_dates=week_dates,
                         DAY_NAMES=DAY_NAMES,
                         DISH_TYPES=DISH_TYPES)


# ======================= ОТЧЁТЫ (АДМИН) =======================

@app.route('/reports/orders')
@admin_required
def report_orders():
    """Отчёт о заказанных блюдах"""
    # Берём последний оплаченный заказ или все за неделю
    week_start = get_next_week_start()
    
    # Получаем все оплаченные заказы за неделю
    week_end = week_start + timedelta(days=6)
    orders = Order.query.filter(
        Order.week_start_date >= week_start,
        Order.week_start_date <= week_end,
        Order.status.in_(['paid', 'confirmed'])
    ).all()
    
    # Подсчитываем блюда
    dish_counts = {}
    day_totals = {day: 0 for day in range(1, 7)}
    total_amount = 0
    
    for order in orders:
        for item in order.items:
            key = f"{item.day_of_week}_{item.dish_id}"
            if key not in dish_counts:
                dish_counts[key] = {
                    'day': item.day_of_week,
                    'dish': item.dish,
                    'count': 0,
                    'amount': 0
                }
            dish_counts[key]['count'] += item.quantity
            dish_counts[key]['amount'] += item.dish.price * item.quantity
            day_totals[item.day_of_week] += item.dish.price * item.quantity
            total_amount += item.dish.price * item.quantity
    
    week_dates = week_range(week_start)
    
    return render_template('reports/orders.html',
                         orders=orders,
                         dish_counts=dish_counts,
                         day_totals=day_totals,
                         total_amount=total_amount,
                         week_start=week_start,
                         week_dates=week_dates,
                         DAY_NAMES=DAY_NAMES)


@app.route('/reports/table-cards')
@admin_required
def report_table_cards():
    """Генерация карточек для официантов (DOCX)"""
    from docx import Document
    from docx.shared import Pt, Inches, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    
    week_start = get_next_week_start()
    week_end = week_start + timedelta(days=6)
    
    orders = Order.query.filter(
        Order.week_start_date >= week_start,
        Order.week_start_date <= week_end,
        Order.status.in_(['paid', 'confirmed'])
    ).all()
    
    # Создаём документ
    doc = Document()
    
    # Настраиваем поля
    for section in doc.sections:
        section.top_margin = Cm(0.3)
        section.bottom_margin = Cm(0.3)
        section.left_margin = Cm(0.5)
        section.right_margin = Cm(0.5)
    
    # Для каждого заказа создаём строку
    for order in orders:
        user = order.user
        
        # Формируем строку заказа
        items_text = []
        
        # Группируем по дням
        by_day = {}
        for item in order.items:
            if item.day_of_week not in by_day:
                by_day[item.day_of_week] = []
            by_day[item.day_of_week].append(item)
        
        for day in range(1, 7):
            if day in by_day:
                for item in by_day[day]:
                    dish_name = get_short_dish_name(item.dish, day)
                    if item.quantity > 1:
                        items_text.append(f"{dish_name}*{item.quantity}")
                    else:
                        items_text.append(dish_name)
        
        if items_text:
            line = f"{user.surname or '??'} {user.student_class or ''}\t" + "+".join(items_text)
        else:
            line = f"{user.surname or '??'} {user.student_class or ''}\tПустой заказ"
        
        # Добавляем параграф
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        
        run = p.add_run(line)
        run.font.size = Pt(12)
        run.font.name = 'Arial'
    
    # Сохраняем
    doc_path = os.path.join(app.config['UPLOAD_FOLDER'], 'table_cards.docx')
    doc.save(doc_path)
    
    return send_file(doc_path, as_attachment=True, download_name='table_cards.docx')


def get_short_dish_name(dish, day):
    """Получить сокращённое название блюда или тип"""
    # Проверяем, только ли одно блюдо этого типа в этот день
    day_menu = ModuleMenu.query.filter_by(day_of_week=day).all()
    type_count = sum(1 for m in day_menu if m.dish_type == dish.dish_type and m.dish_id == dish.id)
    total_of_type = len([m for m in day_menu if m.dish_type == dish.dish_type])
    
    if total_of_type == 1:
        # Только одно блюдо этого типа - используем тип
        type_map = {
            'Суп': 'суп',
            'Салат': 'салат',
            'Второе горячее блюдо': 'второе',
            'Гарнир': 'гарнир',
            'Напиток': 'напиток',
            'Готовое кулинарное блюдо': 'блюдо',
            'Хлеб': 'хлеб'
        }
        return type_map.get(dish.dish_type, dish.dish_type)
    
    # Используем краткое название или первое слово
    if dish.short_name:
        return dish.short_name
    return dish.name.split()[0] if dish.name else dish.dish_type


# ======================= УПРАВЛЕНИЕ ОПЛАТАМИ (АДМИН) =======================

@app.route('/admin/payments')
@admin_required
def admin_payments():
    """Управление оплатами"""
    status_filter = request.args.get('status', 'all')
    
    query = Order.query.filter(Order.status.in_(['paid', 'confirmed', 'problem']))
    
    if status_filter == 'paid':
        query = query.filter_by(status='confirmed')
    elif status_filter == 'problem':
        query = query.filter_by(status='problem')
    elif status_filter == 'pending':
        query = query.filter_by(status='paid')
    
    orders = query.order_by(Order.created_at.desc()).all()
    
    return render_template('admin/payments.html', orders=orders, status_filter=status_filter)


@app.route('/admin/payments/<int:order_id>/<action>', methods=['POST'])
@admin_required
def admin_payment_action(order_id, action):
    """Подтвердить или отклонить оплату"""
    order = Order.query.get_or_404(order_id)
    
    if action == 'confirm':
        order.status = 'confirmed'
        flash('Оплата подтверждена', 'success')
    elif action == 'reject':
        order.status = 'problem'
        flash('Заказ помечен как проблемный', 'warning')
    elif action == 'restore':
        order.status = 'paid'
        flash('Статус восстановлен', 'info')
    
    db.session.commit()
    return redirect(url_for('admin_payments'))


# ======================= ИНИЦИАЛИЗАЦИЯ БАЗЫ =======================

def init_db():
    """Инициализация базы данных и демо-данных"""
    db.create_all()
    
    # Создаём админа если нет
    admin = User.query.filter_by(email='admin@school.ru').first()
    if not admin:
        admin = User(
            email='admin@school.ru',
            name='Администратор',
            surname='Системный',
            student_class='admin',
            is_admin=True
        )
        db.session.add(admin)
        db.session.commit()
    
    # Добавляем примеры блюд если пусто
    if Dish.query.count() == 0:
        sample_dishes = [
            Dish(name='Борщ', composition='Свекла, капуста, мясо', quantity='250 г', price=85, dish_type='Суп', is_supplier=True),
            Dish(name='Суп с фрикадельками', composition='Мясо, картофель', quantity='250 г', price=110, dish_type='Суп', is_supplier=True),
            Dish(name='Компот', composition='Ягоды, сахар', quantity='200 г', price=40, dish_type='Напиток', is_supplier=True),
            Dish(name='Салат Овощной', composition='Овощи', quantity='100 г', price=55, dish_type='Салат', is_supplier=True),
            Dish(name='Каша гречневая', composition='Гречка, масло', quantity='150 г', price=40, dish_type='Гарнир', is_supplier=True),
            Dish(name='Котлеты', composition='Мясо, хлеб', quantity='100 г', price=135, dish_type='Второе горячее блюдо', is_supplier=True),
            Dish(name='Чай', composition='Чай, сахар', quantity='200 г', price=25, dish_type='Напиток', is_supplier=True),
        ]
        for dish in sample_dishes:
            db.session.add(dish)
        db.session.commit()


# ======================= ЗАПУСК =======================

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True, port=5000)