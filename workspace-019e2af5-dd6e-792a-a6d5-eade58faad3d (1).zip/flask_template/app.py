import os
import sqlite3
import json
from datetime import datetime, timedelta
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, session, g, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'super-secret-key-change-me-in-production'
app.config['DATABASE'] = os.path.join(app.instance_path, 'database.db')

# ─── DATABASE ────────────────────────────────────────────────────────────────

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    os.makedirs(app.instance_path, exist_ok=True)
    db = sqlite3.connect(app.config['DATABASE'])
    db.row_factory = sqlite3.Row
    db.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            avatar_color TEXT DEFAULT '#6366f1',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            icon TEXT DEFAULT '📦',
            description TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            price REAL NOT NULL,
            old_price REAL DEFAULT NULL,
            category_id INTEGER,
            image_url TEXT DEFAULT '',
            rating REAL DEFAULT 4.5,
            reviews_count INTEGER DEFAULT 0,
            in_stock INTEGER DEFAULT 1,
            featured INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id)
        );
        CREATE TABLE IF NOT EXISTS cart_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            total REAL NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            price REAL NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            description TEXT DEFAULT '',
            event_date DATE NOT NULL,
            event_time TEXT DEFAULT '12:00',
            color TEXT DEFAULT '#6366f1',
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            rating INTEGER DEFAULT 5,
            comment TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (product_id) REFERENCES products(id)
        );
    ''')
    # Seed data
    count = db.execute('SELECT COUNT(*) FROM categories').fetchone()[0]
    if count == 0:
        categories = [
            ('Электроника', '💻', 'Ноутбуки, смартфоны, планшеты и аксессуары'),
            ('Одежда', '👕', 'Мужская и женская одежда, обувь'),
            ('Дом и сад', '🏡', 'Мебель, декор, садовый инвентарь'),
            ('Спорт', '⚽', 'Спортивное оборудование и одежда'),
            ('Книги', '📚', 'Художественная и учебная литература'),
            ('Игрушки', '🧸', 'Детские игрушки и настольные игры'),
            ('Авто', '🚗', 'Автозапчасти и аксессуары'),
            ('Красота', '💄', 'Косметика и средства по уходу'),
        ]
        db.executemany('INSERT INTO categories (name, icon, description) VALUES (?, ?, ?)', categories)

        products = [
            ('MacBook Pro 16"', 'Мощный ноутбук для профессионалов с чипом M3 Pro, 18 ГБ RAM, 512 ГБ SSD', 249990, 279990, 1, '', 4.8, 234, 1, 1),
            ('iPhone 15 Pro Max', 'Титановый корпус, камера 48 Мп, чип A17 Pro, Dynamic Island', 159990, None, 1, '', 4.9, 567, 1, 1),
            ('AirPods Pro 2', 'Активное шумоподавление, адаптивный звук, USB-C', 24990, 27990, 1, '', 4.7, 890, 1, 0),
            ('Samsung Galaxy S24 Ultra', 'AI-функции, S Pen, камера 200 Мп, титановая рамка', 134990, 144990, 1, '', 4.6, 345, 1, 1),
            ('Sony WH-1000XM5', 'Лучшие беспроводные наушники с шумоподавлением', 32990, 36990, 1, '', 4.8, 456, 1, 0),
            ('iPad Air M2', 'Планшет с чипом M2, 11" Liquid Retina, поддержка Apple Pencil Pro', 79990, None, 1, '', 4.7, 123, 1, 0),
            ('Куртка North Face', 'Зимняя куртка с утеплителем ThermoBall™, водонепроницаемая', 18990, 24990, 2, '', 4.5, 67, 1, 0),
            ('Кроссовки Nike Air Max', 'Легкие беговые кроссовки с амортизацией Air Max', 12990, 15990, 2, '', 4.4, 234, 1, 1),
            ('Джинсы Levi\'s 501', 'Классические прямые джинсы из премиального денима', 8990, None, 2, '', 4.3, 156, 1, 0),
            ('Диван IKEA Kivik', 'Угловой диван с мягкими подушками, ткань серого цвета', 54990, 64990, 3, '', 4.2, 89, 1, 1),
            ('Набор садовых инструментов', 'Профессиональный набор из 12 предметов из нержавеющей стали', 4990, 6990, 3, '', 4.6, 45, 1, 0),
            ('Велотренажёр Xiaomi', 'Домашний велотренажёр с экраном и Bluetooth', 29990, 39990, 4, '', 4.5, 78, 1, 1),
            ('Гантели разборные 20кг', 'Набор разборных гантелей с покрытием из неопрена', 5990, 7490, 4, '', 4.4, 123, 1, 0),
            ('Гарри Поттер. Полное собрание', 'Все 7 книг в коллекционном издании с иллюстрациями', 4990, 6990, 5, '', 4.9, 567, 1, 1),
            ('LEGO Technic Porsche 911', 'Коллекционная модель 1:8, 1580 деталей', 14990, 17990, 6, '', 4.8, 234, 1, 0),
            ('Автомобильный видеорегистратор', 'Разрешение 4K, GPS-модуль, ночная съемка', 7990, 9990, 7, '', 4.3, 345, 1, 0),
            ('Набор уходовой косметики', 'Премиальный набор из 8 средств для ежедневного ухода', 6990, 9990, 8, '', 4.7, 189, 1, 1),
            ('Apple Watch Series 9', 'Умные часы с датчиком кислорода, ЭКГ и always-on дисплеем', 44990, 49990, 1, '', 4.6, 234, 1, 0),
            ('Робот-пылесос Roborock', 'Лазерная навигация, влажная и сухая уборка, 5100 Па', 34990, 44990, 3, '', 4.7, 567, 1, 1),
            ('Теннисная ракетка Wilson', 'Профессиональная ракетка для большого тенниса', 8990, None, 4, '', 4.5, 56, 1, 0),
        ]
        db.executemany('''INSERT INTO products
            (name, description, price, old_price, category_id, image_url, rating, reviews_count, in_stock, featured)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', products)

        # Demo user
        db.execute('INSERT INTO users (username, email, password_hash, full_name, phone) VALUES (?, ?, ?, ?, ?)',
            ('demo', 'demo@example.com', generate_password_hash('demo123'), 'Иван Петров', '+7 (999) 123-45-67'))

        # Demo events
        today = datetime.now()
        events = [
            (1, 'Созвон с командой', 'Обсуждение нового спринта', today.strftime('%Y-%m-%d'), '10:00', '#6366f1'),
            (1, 'Релиз v2.0', 'Деплой на продакшн', (today + timedelta(days=2)).strftime('%Y-%m-%d'), '14:00', '#ef4444'),
            (1, 'Тренировка', 'Бег 5 км', (today + timedelta(days=1)).strftime('%Y-%m-%d'), '07:00', '#10b981'),
            (1, 'Встреча с клиентом', 'Презентация проекта', (today + timedelta(days=3)).strftime('%Y-%m-%d'), '16:00', '#f59e0b'),
            (1, 'Code Review', 'Ревью pull requests', (today + timedelta(days=5)).strftime('%Y-%m-%d'), '11:00', '#8b5cf6'),
            (1, 'День рождения Маши', 'Не забыть купить подарок!', (today + timedelta(days=7)).strftime('%Y-%m-%d'), '18:00', '#ec4899'),
            (1, 'Вебинар по Python', 'Новые фичи Python 3.13', (today + timedelta(days=4)).strftime('%Y-%m-%d'), '19:00', '#06b6d4'),
        ]
        db.executemany('INSERT INTO events (user_id, title, description, event_date, event_time, color) VALUES (?, ?, ?, ?, ?, ?)', events)

        # Demo orders
        db.execute("INSERT INTO orders (user_id, total, status, created_at) VALUES (1, 274980, 'delivered', ?)", ((today - timedelta(days=15)).strftime('%Y-%m-%d'),))
        db.execute("INSERT INTO orders (user_id, total, status, created_at) VALUES (1, 159990, 'shipped', ?)", ((today - timedelta(days=3)).strftime('%Y-%m-%d'),))
        db.execute("INSERT INTO orders (user_id, total, status, created_at) VALUES (1, 24990, 'processing', ?)", ((today - timedelta(days=1)).strftime('%Y-%m-%d'),))
        db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (1, 1, 1, 249990)")
        db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (1, 3, 1, 24990)")
        db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (2, 2, 1, 159990)")
        db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (3, 3, 1, 24990)")

        # Demo cart
        db.execute("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (1, 5, 1)")
        db.execute("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (1, 8, 2)")
        db.execute("INSERT INTO cart_items (user_id, product_id, quantity) VALUES (1, 14, 1)")

        # Demo reviews
        db.execute("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (1, 1, 5, 'Отличный ноутбук! Работает молниеносно.')")
        db.execute("INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (1, 2, 5, 'Лучший смартфон, что у меня был.')")

    db.commit()
    db.close()

# ─── AUTH HELPERS ─────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Пожалуйста, войдите в систему', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if 'user_id' in session:
        db = get_db()
        return db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    return None

def get_cart_count():
    if 'user_id' in session:
        db = get_db()
        result = db.execute('SELECT COALESCE(SUM(quantity), 0) as cnt FROM cart_items WHERE user_id = ?',
                          (session['user_id'],)).fetchone()
        return result['cnt']
    return 0

@app.context_processor
def inject_globals():
    return {
        'current_user': get_current_user(),
        'cart_count': get_cart_count(),
        'now': datetime.now()
    }

# ─── ROUTES ──────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    db = get_db()
    featured = db.execute('SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.featured = 1 LIMIT 8').fetchall()
    categories = db.execute('SELECT * FROM categories').fetchall()
    return render_template('index.html', featured=featured, categories=categories)

# ── AUTH ──

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        db = get_db()
        username = request.form['username']
        password = request.form['password']
        user = db.execute('SELECT * FROM users WHERE username = ? OR email = ?', (username, username)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            flash('Добро пожаловать!', 'success')
            return redirect(url_for('profile'))
        flash('Неверный логин или пароль', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        db = get_db()
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        full_name = request.form.get('full_name', '')
        try:
            db.execute('INSERT INTO users (username, email, password_hash, full_name) VALUES (?, ?, ?, ?)',
                      (username, email, generate_password_hash(password), full_name))
            db.commit()
            user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
            session['user_id'] = user['id']
            flash('Регистрация прошла успешно!', 'success')
            return redirect(url_for('profile'))
        except sqlite3.IntegrityError:
            flash('Пользователь с таким именем или email уже существует', 'error')
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

# ── PROFILE ──

@app.route('/profile')
@login_required
def profile():
    db = get_db()
    user = get_current_user()
    orders = db.execute('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', (session['user_id'],)).fetchall()
    reviews = db.execute('''SELECT r.*, p.name as product_name FROM reviews r
        JOIN products p ON r.product_id = p.id WHERE r.user_id = ? ORDER BY r.created_at DESC''',
        (session['user_id'],)).fetchall()
    return render_template('profile.html', user=user, orders=orders, reviews=reviews)

@app.route('/profile/edit', methods=['POST'])
@login_required
def profile_edit():
    db = get_db()
    db.execute('UPDATE users SET full_name = ?, phone = ?, email = ? WHERE id = ?',
              (request.form['full_name'], request.form['phone'], request.form['email'], session['user_id']))
    db.commit()
    flash('Профиль обновлён', 'success')
    return redirect(url_for('profile'))

# ── CATALOG ──

@app.route('/catalog')
def catalog():
    db = get_db()
    category_id = request.args.get('category', type=int)
    sort = request.args.get('sort', 'default')
    search = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)
    per_page = 12

    query = 'SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1'
    params = []
    if category_id:
        query += ' AND p.category_id = ?'
        params.append(category_id)
    if search:
        query += ' AND (p.name LIKE ? OR p.description LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%'])

    if sort == 'price_asc':
        query += ' ORDER BY p.price ASC'
    elif sort == 'price_desc':
        query += ' ORDER BY p.price DESC'
    elif sort == 'rating':
        query += ' ORDER BY p.rating DESC'
    elif sort == 'name':
        query += ' ORDER BY p.name ASC'
    else:
        query += ' ORDER BY p.created_at DESC'

    total = db.execute(f'SELECT COUNT(*) FROM ({query})', params).fetchone()[0]
    products = db.execute(query + ' LIMIT ? OFFSET ?', params + [per_page, (page - 1) * per_page]).fetchall()
    categories = db.execute('SELECT * FROM categories').fetchall()
    total_pages = (total + per_page - 1) // per_page

    return render_template('catalog.html', products=products, categories=categories,
                         current_category=category_id, sort=sort, search=search,
                         page=page, total_pages=total_pages, total=total)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    db = get_db()
    product = db.execute('SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?',
                        (product_id,)).fetchone()
    if not product:
        flash('Товар не найден', 'error')
        return redirect(url_for('catalog'))
    reviews = db.execute('''SELECT r.*, u.username, u.avatar_color FROM reviews r
        JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC''',
        (product_id,)).fetchall()
    related = db.execute('SELECT * FROM products WHERE category_id = ? AND id != ? LIMIT 4',
                        (product['category_id'], product_id)).fetchall()
    return render_template('product.html', product=product, reviews=reviews, related=related)

@app.route('/product/<int:product_id>/review', methods=['POST'])
@login_required
def add_review(product_id):
    db = get_db()
    rating = request.form.get('rating', 5, type=int)
    comment = request.form.get('comment', '')
    db.execute('INSERT INTO reviews (user_id, product_id, rating, comment) VALUES (?, ?, ?, ?)',
              (session['user_id'], product_id, rating, comment))
    # Update product rating
    avg = db.execute('SELECT AVG(rating) as avg_r, COUNT(*) as cnt FROM reviews WHERE product_id = ?',
                    (product_id,)).fetchone()
    db.execute('UPDATE products SET rating = ?, reviews_count = ? WHERE id = ?',
              (round(avg['avg_r'], 1), avg['cnt'], product_id))
    db.commit()
    flash('Отзыв добавлен!', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

# ── CART ──

@app.route('/cart')
@login_required
def cart():
    db = get_db()
    items = db.execute('''SELECT ci.*, p.name, p.price, p.old_price, p.image_url, p.in_stock
        FROM cart_items ci JOIN products p ON ci.product_id = p.id
        WHERE ci.user_id = ?''', (session['user_id'],)).fetchall()
    total = sum(item['price'] * item['quantity'] for item in items)
    return render_template('cart.html', items=items, total=total)

@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def cart_add(product_id):
    db = get_db()
    qty = request.form.get('quantity', 1, type=int)
    existing = db.execute('SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?',
                         (session['user_id'], product_id)).fetchone()
    if existing:
        db.execute('UPDATE cart_items SET quantity = quantity + ? WHERE id = ?', (qty, existing['id']))
    else:
        db.execute('INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)',
                  (session['user_id'], product_id, qty))
    db.commit()
    flash('Товар добавлен в корзину!', 'success')
    next_url = request.form.get('next', url_for('catalog'))
    return redirect(next_url)

@app.route('/cart/update/<int:item_id>', methods=['POST'])
@login_required
def cart_update(item_id):
    db = get_db()
    qty = request.form.get('quantity', 1, type=int)
    if qty <= 0:
        db.execute('DELETE FROM cart_items WHERE id = ? AND user_id = ?', (item_id, session['user_id']))
    else:
        db.execute('UPDATE cart_items SET quantity = ? WHERE id = ? AND user_id = ?', (qty, item_id, session['user_id']))
    db.commit()
    return redirect(url_for('cart'))

@app.route('/cart/remove/<int:item_id>', methods=['POST'])
@login_required
def cart_remove(item_id):
    db = get_db()
    db.execute('DELETE FROM cart_items WHERE id = ? AND user_id = ?', (item_id, session['user_id']))
    db.commit()
    flash('Товар удалён из корзины', 'info')
    return redirect(url_for('cart'))

@app.route('/cart/checkout', methods=['POST'])
@login_required
def checkout():
    db = get_db()
    items = db.execute('''SELECT ci.*, p.price FROM cart_items ci
        JOIN products p ON ci.product_id = p.id WHERE ci.user_id = ?''', (session['user_id'],)).fetchall()
    if not items:
        flash('Корзина пуста', 'warning')
        return redirect(url_for('cart'))
    total = sum(i['price'] * i['quantity'] for i in items)
    db.execute('INSERT INTO orders (user_id, total, status) VALUES (?, ?, ?)',
              (session['user_id'], total, 'processing'))
    order_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
    for item in items:
        db.execute('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
                  (order_id, item['product_id'], item['quantity'], item['price']))
    db.execute('DELETE FROM cart_items WHERE user_id = ?', (session['user_id'],))
    db.commit()
    flash(f'Заказ #{order_id} оформлен!', 'success')
    return redirect(url_for('profile'))

# ── TABLES ──

@app.route('/tables')
def tables():
    db = get_db()
    products = db.execute('SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY p.id').fetchall()
    users = db.execute('SELECT id, username, email, full_name, phone, created_at FROM users').fetchall()
    orders = db.execute('''SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC''').fetchall()
    return render_template('tables.html', products=products, users=users, orders=orders)

# ── STATISTICS ──

@app.route('/statistics')
def statistics():
    db = get_db()
    total_products = db.execute('SELECT COUNT(*) FROM products').fetchone()[0]
    total_users = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    total_orders = db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    total_revenue = db.execute('SELECT COALESCE(SUM(total), 0) FROM orders').fetchone()[0]
    avg_rating = db.execute('SELECT COALESCE(AVG(rating), 0) FROM products').fetchone()[0]
    total_reviews = db.execute('SELECT COUNT(*) FROM reviews').fetchone()[0]

    cat_stats = db.execute('''SELECT c.name, COUNT(p.id) as product_count, COALESCE(AVG(p.price), 0) as avg_price
        FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id''').fetchall()

    order_statuses = db.execute('''SELECT status, COUNT(*) as cnt FROM orders GROUP BY status''').fetchall()

    top_products = db.execute('''SELECT name, rating, reviews_count, price FROM products ORDER BY rating DESC LIMIT 5''').fetchall()

    return render_template('statistics.html',
        total_products=total_products, total_users=total_users,
        total_orders=total_orders, total_revenue=total_revenue,
        avg_rating=round(avg_rating, 1), total_reviews=total_reviews,
        cat_stats=cat_stats, order_statuses=order_statuses, top_products=top_products)

# ── CALENDAR ──

@app.route('/calendar')
def calendar_view():
    db = get_db()
    year = request.args.get('year', datetime.now().year, type=int)
    month = request.args.get('month', datetime.now().month, type=int)
    user_id = session.get('user_id', 1)
    events = db.execute('SELECT * FROM events WHERE user_id = ?', (user_id,)).fetchall()
    events_list = [dict(e) for e in events]
    return render_template('calendar.html', events=events_list, year=year, month=month)

@app.route('/calendar/add', methods=['POST'])
@login_required
def calendar_add():
    db = get_db()
    db.execute('INSERT INTO events (user_id, title, description, event_date, event_time, color) VALUES (?, ?, ?, ?, ?, ?)',
        (session['user_id'], request.form['title'], request.form.get('description', ''),
         request.form['event_date'], request.form.get('event_time', '12:00'), request.form.get('color', '#6366f1')))
    db.commit()
    flash('Событие добавлено!', 'success')
    return redirect(url_for('calendar_view'))

@app.route('/calendar/delete/<int:event_id>', methods=['POST'])
@login_required
def calendar_delete(event_id):
    db = get_db()
    db.execute('DELETE FROM events WHERE id = ? AND user_id = ?', (event_id, session['user_id']))
    db.commit()
    return redirect(url_for('calendar_view'))

# ── MENU (restaurant/food) ──

@app.route('/menu')
def menu():
    menu_items = {
        'Завтраки': [
            {'name': 'Яйца Бенедикт', 'desc': 'Пашот, голландский соус, бекон, маффин', 'price': 490, 'tag': 'Популярное', 'cal': 380},
            {'name': 'Авокадо-тост', 'desc': 'Чиабатта, авокадо, яйцо пашот, микс семян', 'price': 420, 'tag': 'Веган', 'cal': 310},
            {'name': 'Сырники со сметаной', 'desc': 'Домашние сырники, сметана, ягодный соус', 'price': 350, 'tag': '', 'cal': 290},
            {'name': 'Гранола с йогуртом', 'desc': 'Домашняя гранола, греческий йогурт, свежие ягоды', 'price': 380, 'tag': 'ЗОЖ', 'cal': 250},
        ],
        'Супы': [
            {'name': 'Том Ям с креветками', 'desc': 'Кокосовое молоко, тигровые креветки, грибы шиитаке', 'price': 590, 'tag': 'Острое 🌶️', 'cal': 220},
            {'name': 'Крем-суп из тыквы', 'desc': 'Запечённая тыква, сливки, тыквенные семечки', 'price': 390, 'tag': 'Сезонное', 'cal': 180},
            {'name': 'Борщ', 'desc': 'Классический рецепт, сметана, пампушки с чесноком', 'price': 420, 'tag': '', 'cal': 310},
        ],
        'Горячее': [
            {'name': 'Стейк Рибай', 'desc': 'Мраморная говядина 300г, овощи гриль, соус демиглас', 'price': 1890, 'tag': 'Хит', 'cal': 650},
            {'name': 'Лосось на гриле', 'desc': 'Филе лосося, спаржа, лимонный соус', 'price': 1290, 'tag': 'ЗОЖ', 'cal': 420},
            {'name': 'Паста Карбонара', 'desc': 'Спагетти, гуанчиале, пекорино романо, яичный соус', 'price': 690, 'tag': 'Популярное', 'cal': 520},
            {'name': 'Бургер Black Angus', 'desc': 'Котлета 200г, чеддер, бекон, трюфельный соус, картофель фри', 'price': 790, 'tag': '', 'cal': 780},
        ],
        'Десерты': [
            {'name': 'Тирамису', 'desc': 'Классический итальянский десерт с маскарпоне', 'price': 450, 'tag': 'Популярное', 'cal': 380},
            {'name': 'Чизкейк Нью-Йорк', 'desc': 'Сливочный чизкейк, ягодный соус', 'price': 420, 'tag': '', 'cal': 410},
            {'name': 'Шоколадный фондан', 'desc': 'Тёплый шоколадный кекс с жидким центром, ванильное мороженое', 'price': 490, 'tag': 'Хит', 'cal': 520},
        ],
        'Напитки': [
            {'name': 'Капучино', 'desc': 'Двойной эспрессо, вспененное молоко', 'price': 290, 'tag': '', 'cal': 120},
            {'name': 'Матча латте', 'desc': 'Японский матча, овсяное молоко', 'price': 350, 'tag': 'ЗОЖ', 'cal': 140},
            {'name': 'Свежевыжатый сок', 'desc': 'Апельсин / яблоко / морковь', 'price': 320, 'tag': 'Витамины', 'cal': 110},
            {'name': 'Смузи "Тропик"', 'desc': 'Манго, маракуйя, банан, кокосовое молоко', 'price': 390, 'tag': '', 'cal': 190},
        ],
    }
    return render_template('menu.html', menu_items=menu_items)

# ─── API for charts ──

@app.route('/api/stats')
def api_stats():
    db = get_db()
    cats = db.execute('''SELECT c.name, COUNT(p.id) as cnt, COALESCE(SUM(p.price), 0) as total_price
        FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id''').fetchall()
    return jsonify([dict(c) for c in cats])

# ─── INIT & RUN ───

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
