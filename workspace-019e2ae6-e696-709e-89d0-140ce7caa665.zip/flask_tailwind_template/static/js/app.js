document.addEventListener('DOMContentLoaded', () => {
  const mobileButton = document.querySelector('[data-mobile-menu-button]');
  const mobileMenu = document.querySelector('[data-mobile-menu]');
  if (mobileButton && mobileMenu) {
    mobileButton.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
  }

  document.querySelectorAll('[data-filter-table]').forEach((input) => {
    const target = document.querySelector(input.dataset.filterTable);
    if (!target) return;
    input.addEventListener('input', () => {
      const q = input.value.toLowerCase();
      target.querySelectorAll('tbody tr').forEach((row) => {
        row.style.display = row.innerText.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });
});
