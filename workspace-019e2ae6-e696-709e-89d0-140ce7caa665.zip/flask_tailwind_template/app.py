from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path

from flask import (
    Flask,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "instance" / "app.sqlite"

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-me-in-production")
app.config["DATABASE"] = str(DB_PATH)


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        DB_PATH.parent.mkdir(exist_ok=True)
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = get_db()
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'customer',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            category TEXT NOT NULL,
            price INTEGER NOT NULL,
            old_price INTEGER,
            stock INTEGER NOT NULL DEFAULT 0,
            rating REAL NOT NULL DEFAULT 0,
            description TEXT NOT NULL,
            specs TEXT NOT NULL,
            badge TEXT
        );

        CREATE TABLE IF NOT EXISTS cart_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, product_id),
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(product_id) REFERENCES products(id)
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            total INTEGER NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """
    )

    count = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if count == 0:
        db.execute(
            "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (
                "Демо Пользователь",
                "demo@example.com",
                generate_password_hash("demo12345"),
                "customer",
                datetime.now().isoformat(timespec="seconds"),
            ),
        )

    product_count = db.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if product_count == 0:
        products = [
            ("Urban Pack 22L", "urban-pack-22l", "Рюкзаки", 7490, 8990, 18, 4.8, "Городской рюкзак с жёстким отделением под ноутбук, влагозащитой и скрытым карманом.", "Материал: нейлон 900D; Объём: 22 л; Ноутбук: до 16”; Вес: 810 г", "Хит"),
            ("Desk Lamp Mono", "desk-lamp-mono", "Дом", 4290, None, 34, 4.7, "Настольная лампа с тёплым светом, сенсорным управлением и металлическим корпусом.", "Свет: 3000K; Мощность: 8 Вт; Корпус: алюминий; Гарантия: 2 года", "Новинка"),
            ("Notebook Grid A5", "notebook-grid-a5", "Канцелярия", 890, 1190, 120, 4.6, "Плотный блокнот в клетку для заметок, планов, скетчей и ежедневного ведения задач.", "Формат: A5; Страниц: 192; Бумага: 100 г/м²; Обложка: ткань", None),
            ("Ceramic Cup 350", "ceramic-cup-350", "Кухня", 1290, None, 56, 4.9, "Минималистичная керамическая чашка с матовым покрытием и удобной ручкой.", "Объём: 350 мл; Материал: керамика; Можно мыть в ПММ; Цвет: графит", "Выбор"),
            ("Cable Organizer", "cable-organizer", "Аксессуары", 590, None, 240, 4.5, "Компактный органайзер для проводов, зарядок, флешек и небольших аксессуаров.", "Размер: 18×11 см; Отделений: 7; Материал: полиэстер; Застёжка: молния", None),
            ("Travel Bottle Steel", "travel-bottle-steel", "Спорт", 2490, 2990, 42, 4.8, "Термобутылка из стали, сохраняет температуру напитков и помещается в боковой карман рюкзака.", "Объём: 600 мл; Сталь: 18/8; Тепло: до 12 ч; Холод: до 24 ч", "Sale"),
            ("Keyboard Stand", "keyboard-stand", "Рабочее место", 1990, None, 73, 4.4, "Алюминиевая подставка для клавиатуры и планшета, помогает освободить место на столе.", "Материал: алюминий; Угол: 12°; Ножки: силикон; Цвет: серебро", None),
            ("Wall Clock Quiet", "wall-clock-quiet", "Дом", 3190, None, 27, 4.7, "Тихие настенные часы с лаконичным циферблатом для кабинета, кухни или спальни.", "Диаметр: 30 см; Механизм: бесшумный; Питание: AA; Корпус: ABS", "Тихий ход"),
        ]
        db.executemany(
            "INSERT INTO products (title, slug, category, price, old_price, stock, rating, description, specs, badge) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            products,
        )

    order_count = db.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    if order_count == 0:
        user_id = db.execute("SELECT id FROM users WHERE email = ?", ("demo@example.com",)).fetchone()[0]
        orders = []
        statuses = ["Доставлен", "В пути", "Собирается", "Отменён"]
        for i in range(1, 7):
            orders.append((user_id, 2800 + i * 1350, statuses[i % len(statuses)], (datetime.now() - timedelta(days=i * 9)).isoformat(timespec="seconds")))
        db.executemany("INSERT INTO orders (user_id, total, status, created_at) VALUES (?, ?, ?, ?)", orders)

    db.commit()


@app.before_request
def load_user():
    init_db()
    user_id = session.get("user_id")
    g.user = None
    if user_id:
        g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            flash("Войдите в аккаунт, чтобы открыть этот раздел.", "info")
            return redirect(url_for("login", next=request.path))
        return view(**kwargs)

    return wrapped_view


@app.template_filter("rub")
def rub(value):
    return f"{int(value):,}".replace(",", " ") + " ₽"


@app.context_processor
def inject_globals():
    cart_count = 0
    if g.get("user"):
        row = get_db().execute("SELECT COALESCE(SUM(quantity), 0) FROM cart_items WHERE user_id = ?", (g.user["id"],)).fetchone()
        cart_count = row[0]
    return {"cart_count": cart_count}


@app.route("/")
def index():
    products = get_db().execute("SELECT * FROM products ORDER BY rating DESC LIMIT 4").fetchall()
    return render_template("index.html", products=products)


@app.route("/tables")
def tables():
    rows = [
        {"id": 1001, "client": "ООО Север", "project": "B2B-портал", "manager": "Анна", "status": "В работе", "priority": "Высокий", "budget": 340000, "date": "2026-01-18"},
        {"id": 1002, "client": "FitLab", "project": "Каталог услуг", "manager": "Илья", "status": "На проверке", "priority": "Средний", "budget": 175000, "date": "2026-01-21"},
        {"id": 1003, "client": "Mono Home", "project": "Интернет-магазин", "manager": "Мария", "status": "Готов", "priority": "Низкий", "budget": 520000, "date": "2026-01-25"},
        {"id": 1004, "client": "EduSpace", "project": "Личный кабинет", "manager": "Олег", "status": "Риск", "priority": "Высокий", "budget": 410000, "date": "2026-01-28"},
        {"id": 1005, "client": "GreenWay", "project": "CRM-модуль", "manager": "София", "status": "В работе", "priority": "Средний", "budget": 290000, "date": "2026-02-02"},
        {"id": 1006, "client": "Market One", "project": "Аналитика", "manager": "Денис", "status": "Готов", "priority": "Высокий", "budget": 610000, "date": "2026-02-07"},
    ]
    return render_template("tables.html", rows=rows)


@app.route("/menu")
def menu():
    return render_template("menu.html")


@app.route("/stats")
def stats():
    products = get_db().execute("SELECT * FROM products ORDER BY stock DESC LIMIT 5").fetchall()
    orders = get_db().execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT 6").fetchall()
    return render_template("stats.html", products=products, orders=orders)


@app.route("/catalog")
def catalog():
    category = request.args.get("category", "")
    q = request.args.get("q", "").strip()
    db = get_db()
    categories = [r[0] for r in db.execute("SELECT DISTINCT category FROM products ORDER BY category").fetchall()]
    sql = "SELECT * FROM products WHERE 1=1"
    params = []
    if category:
        sql += " AND category = ?"
        params.append(category)
    if q:
        sql += " AND (title LIKE ? OR description LIKE ? OR category LIKE ?)"
        params.extend([f"%{q}%", f"%{q}%", f"%{q}%"])
    sql += " ORDER BY rating DESC, title"
    products = db.execute(sql, params).fetchall()
    return render_template("catalog.html", products=products, categories=categories, active_category=category, q=q)


@app.route("/product/<slug>")
def product_detail(slug):
    product = get_db().execute("SELECT * FROM products WHERE slug = ?", (slug,)).fetchone()
    if not product:
        flash("Товар не найден.", "error")
        return redirect(url_for("catalog"))
    related = get_db().execute("SELECT * FROM products WHERE category = ? AND id != ? LIMIT 3", (product["category"], product["id"])).fetchall()
    return render_template("product.html", product=product, related=related)


@app.post("/cart/add/<int:product_id>")
@login_required
def add_to_cart(product_id):
    quantity = max(1, int(request.form.get("quantity", 1)))
    db = get_db()
    product = db.execute("SELECT * FROM products WHERE id = ?", (product_id,)).fetchone()
    if not product:
        flash("Товар не найден.", "error")
        return redirect(url_for("catalog"))
    existing = db.execute("SELECT * FROM cart_items WHERE user_id = ? AND product_id = ?", (g.user["id"], product_id)).fetchone()
    if existing:
        db.execute("UPDATE cart_items SET quantity = quantity + ? WHERE id = ?", (quantity, existing["id"]))
    else:
        db.execute(
            "INSERT INTO cart_items (user_id, product_id, quantity, created_at) VALUES (?, ?, ?, ?)",
            (g.user["id"], product_id, quantity, datetime.now().isoformat(timespec="seconds")),
        )
    db.commit()
    flash(f"{product['title']} добавлен в корзину.", "success")
    return redirect(request.referrer or url_for("cart"))


@app.route("/cart", methods=["GET", "POST"])
@login_required
def cart():
    db = get_db()
    if request.method == "POST":
        action = request.form.get("action")
        item_id = request.form.get("item_id")
        if action == "clear":
            db.execute("DELETE FROM cart_items WHERE user_id = ?", (g.user["id"],))
            flash("Корзина очищена.", "info")
        elif action == "remove" and item_id:
            db.execute("DELETE FROM cart_items WHERE id = ? AND user_id = ?", (item_id, g.user["id"]))
            flash("Позиция удалена.", "info")
        elif action == "update" and item_id:
            quantity = max(1, int(request.form.get("quantity", 1)))
            db.execute("UPDATE cart_items SET quantity = ? WHERE id = ? AND user_id = ?", (quantity, item_id, g.user["id"]))
            flash("Количество обновлено.", "success")
        elif action == "checkout":
            rows = db.execute(
                "SELECT ci.quantity, p.price FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.user_id = ?",
                (g.user["id"],),
            ).fetchall()
            total = sum(r["quantity"] * r["price"] for r in rows)
            if total:
                db.execute("INSERT INTO orders (user_id, total, status, created_at) VALUES (?, ?, ?, ?)", (g.user["id"], total, "Собирается", datetime.now().isoformat(timespec="seconds")))
                db.execute("DELETE FROM cart_items WHERE user_id = ?", (g.user["id"],))
                flash("Заказ оформлен. Это демо-сценарий checkout.", "success")
        db.commit()
        return redirect(url_for("cart"))

    items = db.execute(
        """
        SELECT ci.id as item_id, ci.quantity, p.*
        FROM cart_items ci
        JOIN products p ON p.id = ci.product_id
        WHERE ci.user_id = ?
        ORDER BY ci.created_at DESC
        """,
        (g.user["id"],),
    ).fetchall()
    subtotal = sum(item["quantity"] * item["price"] for item in items)
    return render_template("cart.html", items=items, subtotal=subtotal)


@app.route("/account")
@login_required
def account():
    orders = get_db().execute("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC", (g.user["id"],)).fetchall()
    return render_template("account.html", orders=orders)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("account"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Вы вошли в аккаунт.", "success")
            return redirect(request.args.get("next") or url_for("account"))
        flash("Неверный email или пароль.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("account"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(name) < 2 or len(password) < 6 or "@" not in email:
            flash("Проверьте имя, email и пароль от 6 символов.", "error")
            return render_template("register.html")
        try:
            db = get_db()
            db.execute(
                "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)",
                (name, email, generate_password_hash(password), "customer", datetime.now().isoformat(timespec="seconds")),
            )
            db.commit()
            flash("Аккаунт создан. Теперь войдите.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Пользователь с таким email уже существует.", "error")
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
